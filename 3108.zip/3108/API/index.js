    const express = require('express')
    const server = express()

    server.get('/', (req,res,next)=> {
        return res.status(200).send({
            Mensagem: "Servidor Funcionando"
        })
    })

    server.listen(3100, () => {
        console.log("Rodando... ")
    })